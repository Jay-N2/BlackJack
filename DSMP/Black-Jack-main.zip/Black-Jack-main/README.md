# Black-Jack
Blackjack GUI Game created with Python-Tkinter

## Install and Run
* pip install -r requirements.txt
* python Black Jack.py
